# Aula Cerca

Plataforma de clases particulares para primario y secundario. Proyecto preparado para Next.js en Vercel y Supabase.

**Empezá por `GUIA-VERCEL.html`**: se abre con doble clic en un navegador y explica la instalación en Windows, Supabase, autenticación, correos, publicación y uso. También está disponible en `GUIA-VERCEL.md`.

```sh
npm ci
npm run dev
```

Sin variables de Supabase, `/` muestra perfiles ficticios y `/demo` permite explorar el panel sin guardar datos reales. Las cuentas reales requieren la configuración de la guía.

```sh
npm test
npm run build:vercel
```

Incluye reglas SQL con RLS y pruebas de aislamiento entre cuentas. Los servicios reales y la información legal del responsable deben configurarse antes de abrir inscripciones.
