import Catalog from '@/components/catalog';
import { configured } from '@/lib/config';
export const dynamic='force-dynamic';
export default function Home(){return <Catalog demo={!configured()}/>;}
