import Dashboard from '@/components/dashboard';
export const metadata={title:'Panel de demostración',robots:{index:false,follow:false}};
export default function Page(){return <Dashboard demo/>;}
