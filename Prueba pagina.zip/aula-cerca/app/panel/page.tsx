import Dashboard from '@/components/dashboard';
export const metadata={title:'Mis clases'};
export default function Page(){return <Dashboard/>;}
