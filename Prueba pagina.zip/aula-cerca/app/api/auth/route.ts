import { z } from 'zod';
import { database,sameOrigin,errorResponse } from '@/lib/supabase';
import { configured,legalReady,site } from '@/lib/config';
export const dynamic='force-dynamic';
export async function GET(){if(!configured())return Response.json({configured:false,profile:null});try{const db=await database();const {data:{user}}=await db.auth.getUser();if(!user)return Response.json({configured:true,profile:null});const {data,error}=await db.from('profiles').select('id,name,role').eq('id',user.id).single();if(error)throw Error('No se pudo cargar tu perfil.');return Response.json({configured:true,profile:data});}catch(e){return errorResponse(e);}}
export async function POST(req:Request){try{sameOrigin(req);const body=await req.json();const db=await database();const action=z.enum(['login','register','forgot','password','logout']).parse(body.action);if(action==='logout'){const {error}=await db.auth.signOut();if(error)throw Error('No se pudo cerrar la sesión.');return Response.json({ok:true});}
 if(action==='password'){const password=z.string().min(10).max(128).parse(body.password);const {data:{user}}=await db.auth.getUser();if(!user)return Response.json({error:'Volvé a abrir el enlace de recuperación.'},{status:401});const {error}=await db.auth.updateUser({password});if(error)throw Error('No se pudo actualizar la contraseña. Usá otra contraseña o pedí un nuevo enlace.');return Response.json({ok:true});}
 const email=z.string().email().max(254).parse(body.email);
 if(action==='forgot'){await db.auth.resetPasswordForEmail(email,{redirectTo:`${process.env.APP_URL}/auth/confirm`});return Response.json({message:'Si la dirección tiene una cuenta, recibirá un enlace para cambiar la contraseña.'});}
 const password=z.string().min(10).max(128).parse(body.password);
 if(action==='login'){const {error}=await db.auth.signInWithPassword({email,password});if(error)throw Error('No pudimos ingresar. Revisá tu correo, contraseña y confirmación de email.');return Response.json({ok:true});}
 if(!legalReady)throw Error('Las inscripciones todavía no están habilitadas.');
 const signup=z.object({name:z.string().trim().min(2).max(100),role:z.enum(['student','teacher']),adult_confirmed:z.literal(true),accepted:z.literal(true)}).parse(body);
 const {error}=await db.auth.signUp({email,password,options:{data:{name:signup.name,role:signup.role,adult_confirmed:true,terms_version:site.version},emailRedirectTo:`${process.env.APP_URL}/auth/confirm`}});
 if(error)throw Error('No se pudo crear la cuenta. Revisá los datos o intentá más tarde.');return Response.json({message:'Revisá tu correo para confirmar la cuenta. Si ya tenías una cuenta, ingresá o recuperá tu contraseña.'});
 }catch(e){if(e instanceof z.ZodError)return Response.json({error:'Revisá los campos. La contraseña debe tener al menos 10 caracteres y debés aceptar las condiciones.'},{status:400});return errorResponse(e);}}
