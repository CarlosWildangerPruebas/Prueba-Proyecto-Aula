import AuthForm from '@/components/auth-form';
export const metadata={title:'Tu cuenta'};
export default function Page(){return <AuthForm/>;}
