import type { Metadata } from 'next';
import './globals.css';
import { Header, Footer, CookieConsent } from '@/components/shell';
import { Toaster } from '@/components/ui/sonner';
export const metadata:Metadata={title:{default:'Aula Cerca · Encontrá tu profe',template:'%s · Aula Cerca'},description:'Clases particulares para primario y secundario. Conocé docentes y organizá tu aprendizaje.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="es-AR"><body><a className="skip" href="#main">Saltar al contenido</a><Header/>{children}<Footer/><CookieConsent/><Toaster position="top-center"/></body></html>;}
