'use client';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
export function Choice({value,onChange,options,label,id}:{value:string;onChange:(s:string)=>void;options:{value:string;label:string}[];label:string;id?:string}){return <Select value={value} onValueChange={onChange}><SelectTrigger id={id} aria-label={label} className="w-full min-h-11 bg-white"><SelectValue placeholder={label}/></SelectTrigger><SelectContent>{options.map(o=><SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent></Select>;}
export function Check({checked,onChange,children,id}:{checked:boolean;onChange:(b:boolean)=>void;children:React.ReactNode;id:string}){return <div className="check-line"><Checkbox id={id} checked={checked} onCheckedChange={v=>onChange(v===true)}/><label htmlFor={id}>{children}</label></div>;}
