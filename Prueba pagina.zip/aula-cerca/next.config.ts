import type {NextConfig} from 'next';
const nextConfig:NextConfig={
 poweredByHeader:false,
 async headers(){return [{source:'/(.*)',headers:[
 {key:'X-Content-Type-Options',value:'nosniff'},
 {key:'X-Frame-Options',value:'DENY'},
 {key:'Referrer-Policy',value:'strict-origin-when-cross-origin'},
 {key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},
 {key:'Content-Security-Policy',value:"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://*.supabase.co; font-src 'self'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"}
 ]},{source:'/api/(.*)',headers:[{key:'Cache-Control',value:'private, no-store, max-age=0'}]},{source:'/auth/(.*)',headers:[{key:'Cache-Control',value:'private, no-store, max-age=0'}]}];}
};
export default nextConfig;
