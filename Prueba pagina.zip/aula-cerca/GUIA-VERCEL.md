# Aula Cerca — guía para poner tu web en funcionamiento

El proyecto incluye un buscador de docentes, perfiles con fotos, cuentas de alumno/familia y docente, solicitudes de clases y un panel con calendario, planificación, enlaces de videollamada y seguimiento privado. Tiene diseño adaptable a celulares, términos, privacidad y preferencias de cookies.

**No está publicado ni conectado a una base de datos real todavía.** El código está preparado para Vercel y Supabase. Sin las variables de Supabase, el inicio muestra cuatro perfiles ficticios y `/demo` permite probar el panel con cambios temporales. Las cuentas reales se habilitan al configurar los servicios y completar los datos del responsable.

## 1. Qué necesitás

- Una cuenta de GitHub para guardar el código.
- Una cuenta de Vercel para alojar la web.
- Un proyecto nuevo de Supabase para las cuentas, las fotos y los datos.
- Un proveedor SMTP configurado en Supabase para entregar correos de confirmación y recuperación a usuarios reales.
- La identidad, domicilio y correo de contacto del responsable del servicio.

No se compró ningún servicio ni se creó ninguna cuenta por vos. Consultá los límites y condiciones vigentes de cada proveedor antes de elegir un plan. Si el proyecto será administrado por una persona menor de edad, la persona adulta responsable deberá gestionar las contrataciones y cuentas de servicios cuando sus condiciones lo requieran.

## 2. Abrir y probar en Windows

1. Descargá el ZIP y elegí **Extraer todo**. Abrí la carpeta `aula-cerca`.
2. Instalá Node.js 22.13 o superior desde [Node.js](https://nodejs.org/). Si ya lo tenés, `node -v` muestra la versión.
3. Dentro de esa carpeta, hacé clic en la barra de dirección del Explorador, escribí `cmd` y presioná Enter. Se abrirá una consola ubicada en la carpeta correcta.
4. Ejecutá una línea por vez:

```bat
npm ci
npm run dev
```

5. Abrí `http://localhost:3000` en tu navegador. La consola debe quedar abierta mientras probás. Para detener el sitio, presioná Ctrl+C en esa consola.

La primera instalación puede tardar varios minutos. Si no configuraste Supabase, vas a ver ejemplos y no se podrán crear cuentas reales. No hay contraseñas de demostración. Podés abrir `/demo` para probar el calendario y la planificación; esos cambios se pierden al recargar.

## 3. Crear la base de datos en Supabase

1. Ingresá al [panel de Supabase](https://supabase.com/dashboard) y creá un proyecto nuevo. Elegí la región que corresponda a tu operación y conservá la contraseña de base de datos de forma segura.
2. Abrí **SQL Editor → New query**.
3. Abrí el archivo `supabase/schema.sql` de este proyecto con un editor de texto, copiá su contenido completo y pegalo en el editor SQL de Supabase.
4. Ejecutalo una sola vez. Crea las tablas, las restricciones, el registro automático de perfiles y las políticas de seguridad, además del contenedor público `teacher-photos`.
5. No desactives **Row Level Security (RLS)**. Es la protección que evita que un alumno vea las clases de otro o las notas privadas de un profesor.
6. En las opciones de API/Connect del proyecto, copiá la **Project URL** y la clave **publishable** o la clave pública heredada **anon**. La variable del proyecto se llama `SUPABASE_ANON_KEY` y acepta ambas. No uses `service_role` ni una clave `secret`.

El SQL es para un proyecto nuevo. Si recibís “already exists”, no borres tablas ni lo ejecutes parcialmente al azar: comprobá si ya se aplicó. Para cambiar una base con usuarios, prepará una migración nueva y un respaldo.

## 4. Subir el código a GitHub

Podés usar GitHub Desktop o la interfaz de GitHub. Creá un repositorio privado y subí el contenido de `aula-cerca`. En la raíz del repositorio deben quedar `package.json`, `package-lock.json`, `vercel.json`, `app`, `components`, `lib`, `public` y `supabase`.

No subas `node_modules`, `.next`, archivos `.env.local` ni contraseñas. El `.gitignore` ya los excluye. El archivo `.env.example` contiene solamente nombres de variables y valores vacíos, por lo que sí puede compartirse.

Si usás GitHub Desktop: elegí **File → Add local repository**, seleccioná la carpeta, creá el repositorio si te lo propone, hacé el primer commit y después **Publish repository**, manteniendo el repositorio privado si lo preferís.

## 5. Primera publicación en Vercel

1. Entrá a [Vercel](https://vercel.com/) y elegí **Add New → Project**.
2. Conectá GitHub, autorizá el repositorio y elegí **Import**.
3. Elegí **Next.js** como framework. La raíz debe ser la carpeta donde está `package.json`. Si subiste una carpeta contenedora, seleccioná `aula-cerca` como **Root Directory**.
4. `vercel.json` ya indica `npm ci` para instalar y `npm run build:vercel` para compilar. No uses una exportación estática: las cuentas necesitan las rutas de servidor.
5. Hacé un primer **Deploy** sin conectar Supabase. Esto permite obtener la dirección definitiva, por ejemplo `https://tu-proyecto.vercel.app`, con el sitio en demostración.

Vercel soporta el despliegue de Next.js; la configuración se basa en su [documentación de Next.js](https://vercel.com/docs/frameworks/full-stack/nextjs).

## 6. Configurar las variables reales

En Vercel, abrí tu proyecto → **Settings → Environment Variables** y agregá:

| Variable | Qué poner |
|---|---|
| `APP_URL` | URL de producción exacta, por ejemplo `https://tu-proyecto.vercel.app`, sin barra al final. |
| `SUPABASE_URL` | Project URL de Supabase, como `https://tu-proyecto.supabase.co`. |
| `SUPABASE_ANON_KEY` | Clave publishable o anon del proyecto. Nunca `service_role` ni secret. |
| `NEXT_PUBLIC_OPERATOR_NAME` | Nombre real de la persona o entidad responsable. |
| `NEXT_PUBLIC_OPERATOR_ADDRESS` | Domicilio del responsable para información legal. No uses datos ficticios. |
| `NEXT_PUBLIC_CONTACT_EMAIL` | Correo real que atienda consultas, reportes y solicitudes de privacidad. |

Seleccioná **Production**. Para pruebas separadas, usá un proyecto Supabase de pruebas y variables de Preview propias. No conectes automáticamente despliegues de ramas experimentales a la base de producción.

Después de agregar o modificar variables, hacé un **Redeploy**. Las que comienzan con `NEXT_PUBLIC_` se incorporan al compilar y quedan visibles en la web. Las variables de servidor no se envían al navegador. [Documentación de variables de Vercel](https://vercel.com/docs/environment-variables).

Para probar todo en tu computadora, copiá `.env.example` a `.env.local`, completá los valores y usá `APP_URL=http://localhost:3000`. Reiniciá `npm run dev` después de editar el archivo. No compartas `.env.local`.

## 7. Configurar autenticación y correos

En Supabase:

1. En **Authentication → Providers/Sign In**, habilitá email y contraseña. Dejá activada la confirmación de correo y la posibilidad de registro.
2. En **URL Configuration**, poné en **Site URL** la URL de producción de Vercel. Agregá a las URL permitidas `https://tu-proyecto.vercel.app/auth/confirm`. Para pruebas locales en un proyecto separado, agregá `http://localhost:3000/auth/confirm`.
3. Configurá **Custom SMTP** con un proveedor de correo transaccional. El correo de prueba incluido de Supabase tiene restricciones y no es una solución para enviar a cualquier usuario real. Revisá remitente, dominio, SPF/DKIM y límites. [Guía oficial de SMTP](https://supabase.com/docs/guides/auth/auth-smtp).
4. En **Email Templates → Confirm sign up**, usá el contenido de `supabase/emails/confirm.html`.
5. En **Email Templates → Reset password**, usá `supabase/emails/recovery.html`.
6. Guardá ambas plantillas. **Este paso es necesario:** el proyecto usa `token_hash` para confirmar la cuenta y crear la sesión en el servidor. Las plantillas predeterminadas pueden no completar este flujo.

Los enlaces de las plantillas son:

```html
<!-- Confirmar cuenta -->
<a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email">Confirmar mi cuenta</a>

<!-- Recuperar contraseña -->
<a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery">Cambiar mi contraseña</a>
```

No reemplaces las expresiones entre llaves: Supabase las completa al enviar. Para usar `.SiteURL`, el entorno de Supabase debe apuntar al sitio correcto. [Referencia oficial de plantillas](https://supabase.com/docs/guides/auth/auth-email-templates).

## 8. Completar la información legal antes de abrir inscripciones

Los textos incluidos son una **base editable**, no una certificación de cumplimiento legal. El formulario de registro permanece deshabilitado desde la web mientras falten nombre, domicilio o contacto del responsable.

Revisá `app/legal/[type]/page.tsx` con quien sea responsable legalmente del servicio. Ajustá identidad y contacto, contratación y cancelaciones, jurisdicciones atendidas, regiones de procesamiento, proveedor SMTP, transferencias internacionales y plazos concretos de conservación y respaldo. El texto debe describir la operación real. La [AAIP informa los derechos sobre datos personales en Argentina](https://www.argentina.gob.ar/aaip/datospersonales/derechos).

La versión inicial tiene solo cookies técnicas y una preferencia guardada en el navegador; no lleva analítica ni publicidad. No agregues rastreadores sin modificar los controles y textos que correspondan. Las cuentas para alumnos menores están diseñadas para ser administradas por un adulto responsable.

La comprobación de la información legal en la interfaz no reemplaza la configuración del proveedor: si necesitás mantener el registro totalmente cerrado mientras preparás el lanzamiento, deshabilitá temporalmente **Allow new users to sign up** en Supabase. Habilitalo al finalizar la revisión.

## 9. Cómo se usa

### Docente

1. En **Soy docente**, crea la cuenta y confirma el correo.
2. En **Mi perfil**, sube una foto de hasta 3 MB, completa su presentación, ciudad, materias, nivel y precio por hora.
3. Marca **Publicar mi perfil** y guarda. Desde ese momento aparecerá en el buscador público.
4. En **Solicitudes**, acepta o no acepta solicitudes recibidas.
5. Cuando una solicitud está aceptada, el alumno aparece en **Alumnos** y en el selector de **Nueva clase**.
6. En **Nueva clase**, elige alumno, tema, fecha, inicio y fin, enlace y plan. Los horarios son de Argentina, UTC−3, aunque quien navegue esté en otra zona horaria.
7. Puede editar clases futuras, marcarlas realizadas o cancelarlas. Las clases superpuestas se rechazan también en la base de datos.
8. Las notas de **Alumnos → Seguimiento privado** quedan disponibles solo para ese docente. El plan dentro de una clase sí se comparte con el alumno.

### Alumno o familia

1. Crea una cuenta de **Alumno / familia**, confirma el correo e ingresa.
2. Filtra por nivel, materia, nombre o ciudad y abre el perfil del docente.
3. Envía una solicitud indicando el tema y los horarios posibles.
4. Consulta la respuesta en **Mis clases → Solicitudes**.
5. Cuando el docente programa la clase, aparece en el calendario con el plan y el enlace.

Hay una solicitud por pareja alumno–docente. Una solicitud aceptada establece la relación para programar varias clases. La primera versión no incluye un chat, nuevas solicitudes a un docente que ya declinó la relación ni reactivación de relaciones desde la interfaz; el operador puede gestionar casos de soporte.

### Videollamadas

**Generar enlace de Jitsi** crea una dirección aleatoria y difícil de adivinar. No crea una reserva ni garantiza disponibilidad de la plataforma. Al entrar, el organizador puede necesitar identificarse; el resto accede según las condiciones del proveedor. Para Google Meet o Zoom, creá la reunión en el servicio y pegá su enlace en la clase. No se integró la API de Google Calendar ni Zoom.

Compartí los enlaces únicamente con los participantes. La web no graba videollamadas y no carga servicios de videollamada hasta que se abre el enlace.

## 10. Prueba antes de invitar a usuarios

Después de completar la configuración, hacé esta prueba con dos correos que controles, en navegadores o sesiones separados:

- Registrar un docente y un alumno/familia, y confirmar ambos correos.
- Publicar el perfil del docente con una fotografía propia.
- Enviar y aceptar una solicitud.
- Crear una clase futura y comprobar que aparece en las dos cuentas.
- Crear otra clase superpuesta: debe rechazarse.
- Agregar una nota privada y comprobar que el alumno no la ve.
- Editar/cancelar una clase y revisar el resultado en la otra cuenta.
- Probar cierre de sesión, ingreso y recuperación de contraseña.
- Abrir una videollamada y comprobar el flujo del proveedor.
- Revisar el sitio en tu teléfono, los textos legales y las preferencias de cookies.

La compilación de producción y las pruebas de validación y permisos SQL se ejecutaron durante la preparación del proyecto. No se probó contra tu Supabase real, el envío de correos ni un despliegue real de Vercel porque esas cuentas todavía no están conectadas. Tampoco se hizo una prueba visual en navegador.

Podés repetir las comprobaciones locales:

```bat
npm test
npm run build:vercel
```

Las pruebas SQL usan PostgreSQL mediante PGlite con esquemas de autenticación y almacenamiento simulados. Verifican políticas y restricciones del SQL; no sustituyen una prueba de Supabase Auth y Storage reales.

## 11. Mantenimiento y ayuda

- **No llega el correo:** comprobá Custom SMTP, spam, remitente, límites y logs de Auth. No desactives confirmación como solución automática.
- **El enlace venció o no ingresa:** revisá Site URL, `APP_URL` y ambas plantillas. Los enlaces tienen vencimiento y son de un solo uso.
- **“Solicitud no permitida”:** `APP_URL` debe coincidir con el dominio que estás usando. Para dominios propios, actualizá Vercel, Supabase y esta variable.
- **Sigue mostrando ejemplos:** faltan `SUPABASE_URL` o `SUPABASE_ANON_KEY`, o las agregaste en otro entorno.
- **El buscador está vacío:** con Supabase configurado solo se muestran docentes reales que publicaron su perfil.
- **“No se pudo guardar”:** verificá que se ejecutó el SQL completo y revisá los registros del servicio. No desactives RLS para resolverlo.
- **No aparece un alumno en Nueva clase:** primero debe tener una solicitud aceptada.
- **No se ve una foto:** revisá el contenedor `teacher-photos`, formato, tamaño y permisos. Este proyecto limita las imágenes remotas a dominios estándar de Supabase.

La administración de cuentas, soporte, bajas y moderación se hace inicialmente desde Supabase, con acceso exclusivo del responsable; no hay un panel de administrador dentro de esta versión. Para dar de baja una cuenta, primero identificá su UUID en Auth, eliminá sus fotos en Storage si es docente y luego eliminá el usuario en Auth. La base elimina en cascada su perfil, relaciones, notas y clases. Confirmá antes qué registros debés conservar legalmente y aplicá tus reglas de respaldo. Despublicar un docente no elimina su foto pública.

La aplicación no elimina fotos históricas ni respaldos automáticamente. Al cambiar de formato de imagen puede quedar una versión anterior en Storage. Programá las revisiones y depuraciones necesarias según tu política de conservación. Mantené dependencias, copias de seguridad y credenciales de administración al día.

No están incluidos pagos, facturación, chat, avisos por email de cada clase, sincronización bidireccional con calendarios externos ni verificación automática de títulos. No se muestran reseñas inventadas ni sellos de verificación.

## 12. Archivos principales y personalización

| Archivo | Función |
|---|---|
| `components/catalog.tsx` | Búsqueda y perfiles públicos. |
| `components/dashboard.tsx` | Calendario, solicitudes, alumnos y edición del perfil. |
| `components/auth-form.tsx` | Registro, ingreso y recuperación. |
| `components/shell.tsx` | Marca, navegación, pie y cookies. |
| `app/globals.css` | Colores, tipografías, diseño y adaptación móvil. |
| `app/legal/[type]/page.tsx` | Términos, privacidad y cookies. |
| `app/api` | Operaciones de servidor y control de acceso. |
| `lib/supabase.ts` | Sesiones y cliente de Supabase. |
| `lib/demo.ts` | Datos ficticios, separados de los reales. |
| `supabase/schema.sql` | Tablas, reglas y permisos de la base. |
| `supabase/emails` | Plantillas que se copian a Supabase. |
| `vercel.json` | Configuración para Vercel. |

El nombre provisional es **Aula Cerca**. Para cambiarlo, actualizá la marca en `components/shell.tsx`, los textos y metadatos en `app/layout.tsx`, `lib/config.ts`, las páginas legales y las plantillas de correo. Reemplazá `public/favicon.svg` por tu icono si tenés uno.

El proyecto conserva herramientas de la base de desarrollo para Sites; **Vercel usa Next.js y el comando `build:vercel`**, sin depender de una publicación en Sites. No necesitás tocar la configuración de Cloudflare ni ejecutar `install:ci` en tu computadora.

Las fotografías de la demostración son de stock. Los nombres, biografías y precios no representan a las personas fotografiadas ni ofertas reales. Ver `CREDITOS.md`.
