import { z } from 'zod';
export const levels = ['Primario', 'Secundario'] as const;
export const subjects = ['Matemática','Lengua','Inglés','Física','Química','Historia','Biología','Contabilidad','Apoyo escolar'];
export const meetingUrl = z.string().max(500).refine(v=>{
  if (!v) return true;
  try { const u = new URL(v); return u.protocol==='https:' && !u.username && !u.password && !u.port && (['meet.google.com','meet.jit.si','zoom.us'].includes(u.hostname) || u.hostname.endsWith('.zoom.us')) && u.pathname.length>1; } catch { return false; }
}, 'Usá un enlace HTTPS de Google Meet, Zoom o Jitsi.');
export const teacherSchema = z.object({name:z.string().trim().min(2).max(100),headline:z.string().trim().min(10).max(120),bio:z.string().trim().min(50).max(3000),subjects:z.array(z.string().min(1).max(50)).min(1).max(12),levels:z.array(z.enum(levels)).min(1).max(2),price:z.number().min(0).max(1000000),city:z.string().trim().min(2).max(80),published:z.boolean()});
export const requestSchema = z.object({teacher_id:z.string().uuid(),message:z.string().trim().min(10).max(1500),subject:z.string().min(2).max(50),level:z.enum(levels)});
export const lessonSchema = z.object({id:z.string().uuid().optional(),student_id:z.string().uuid(),title:z.string().trim().min(3).max(120),starts_at:z.string().datetime(),ends_at:z.string().datetime(),meeting_url:meetingUrl,plan:z.string().max(4000)}).refine(v=>Date.parse(v.ends_at)>Date.parse(v.starts_at) && Date.parse(v.ends_at)-Date.parse(v.starts_at)<=8*3600000,'La clase debe durar entre 1 minuto y 8 horas.').refine(v=>Date.parse(v.starts_at)>Date.now(),'Elegí una fecha futura.');
export function makeMeetingLink(id:string) { return `https://meet.jit.si/aulacerca-${id}`; }
