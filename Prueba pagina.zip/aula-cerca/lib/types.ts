export type Teacher = {id:string; name:string; headline:string; bio:string; subjects:string[]; levels:string[]; price:number; city:string; photo_url:string; published:boolean};
export type Profile = {id:string; name:string; role:'teacher'|'student'};
export type RequestRow = {id:string; teacher_id:string; student_id:string; message:string; subject:string; level:string; status:'pending'|'accepted'|'declined'; created_at:string};
export type Lesson = {id:string; teacher_id:string; student_id:string; title:string; starts_at:string; ends_at:string; meeting_url:string; plan:string; status:'planned'|'completed'|'cancelled'};
export type Note = {student_id:string; content:string};
export type DashboardData = {profile:Profile; people:Profile[]; teacher:Teacher|null; requests:RequestRow[]; lessons:Lesson[]; notes:Note[]};
