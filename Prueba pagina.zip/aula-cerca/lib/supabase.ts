import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { configured } from './config';
export async function database() {
  if (!configured()) throw new Error('El servicio todavía no está configurado.');
  const jar = await cookies();
  return createServerClient(process.env.SUPABASE_URL!,process.env.SUPABASE_ANON_KEY!,{
    cookieOptions:{maxAge:60*60*24*30,httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/'},
    cookies:{getAll:()=>jar.getAll(),setAll:list=>{ for(const c of list) jar.set(c.name,c.value,c.options); }}
  });
}
export function sameOrigin(req:Request) {
  const origin=req.headers.get('origin');
  const target=process.env.APP_URL || new URL(req.url).origin;
  if(!origin || origin!==new URL(target).origin) throw new Error('Solicitud no permitida.');
}
export function errorResponse(e:unknown,status=400) {
  const message=e instanceof Error?e.message:'No se pudo completar la operación.';
  return Response.json({error:message},{status});
}
