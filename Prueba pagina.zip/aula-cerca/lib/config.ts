export const site = {
  name: 'Aula Cerca',
  operator: process.env.NEXT_PUBLIC_OPERATOR_NAME || '',
  address: process.env.NEXT_PUBLIC_OPERATOR_ADDRESS || '',
  contact: process.env.NEXT_PUBLIC_CONTACT_EMAIL || '',
  version: '2026-09-01',
};
export const legalReady = Boolean(site.operator && site.address && site.contact);
export const configured = () => Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY);
