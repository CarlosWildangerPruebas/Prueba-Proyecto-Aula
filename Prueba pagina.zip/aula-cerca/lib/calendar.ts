export const timezone='America/Argentina/Buenos_Aires';
export function dayKey(date:Date|string){return new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(date));}
export function timeLabel(date:string){return new Intl.DateTimeFormat('es-AR',{timeZone:timezone,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(date));}
export function longDate(date:string){return new Intl.DateTimeFormat('es-AR',{timeZone:timezone,weekday:'long',day:'numeric',month:'long'}).format(new Date(`${date}T12:00:00-03:00`));}
export function calendarDays(month:Date){const first=new Date(Date.UTC(month.getUTCFullYear(),month.getUTCMonth(),1,12));const offset=(first.getUTCDay()+6)%7;first.setUTCDate(first.getUTCDate()-offset);return Array.from({length:42},(_,i)=>{const date=new Date(first);date.setUTCDate(first.getUTCDate()+i);return date;});}
export function toInputDate(iso:string){return `${dayKey(iso)}T${timeLabel(iso)}`;}
export function fromInputDate(value:string){return new Date(`${value}:00-03:00`).toISOString();}
