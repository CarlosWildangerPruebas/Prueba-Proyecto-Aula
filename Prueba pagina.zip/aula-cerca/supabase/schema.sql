-- Aula Cerca. Ejecutar UNA VEZ en un proyecto nuevo de Supabase.
begin;
create extension if not exists btree_gist with schema extensions;
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 name text not null check(length(name) between 2 and 100),
 role text not null check(role in ('student','teacher')),
 terms_version text not null, accepted_at timestamptz not null default now(),
 adult_confirmed boolean not null check(adult_confirmed)
);
create table public.teachers (
 id uuid primary key references public.profiles(id) on delete cascade,
 name text not null, headline text not null default '', bio text not null default '',
 subjects text[] not null default '{}', levels text[] not null default '{}',
 price numeric not null default 0 check(price between 0 and 1000000), city text not null default '',
 photo_url text not null default '', published boolean not null default false,
 check(levels <@ array['Primario','Secundario']::text[]),
 check(not published or (length(headline)>=10 and length(bio)>=50 and cardinality(subjects)>0 and cardinality(levels)>0 and length(city)>1))
);
create table public.requests (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid not null references public.teachers(id) on delete cascade,
 student_id uuid not null references public.profiles(id) on delete cascade,
 message text not null check(length(message) between 10 and 1500),
 subject text not null check(length(subject) between 2 and 50),
 level text not null check(level in ('Primario','Secundario')),
 status text not null default 'pending' check(status in ('pending','accepted','declined')),
 created_at timestamptz not null default now(),
 unique(teacher_id,student_id),check(teacher_id<>student_id)
);
create table public.lessons (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid not null references public.teachers(id) on delete cascade,
 student_id uuid not null references public.profiles(id) on delete cascade,
 title text not null check(length(title) between 3 and 120),
 starts_at timestamptz not null, ends_at timestamptz not null,
 meeting_url text not null default '' check(meeting_url='' or meeting_url ~ '^https://(meet\.google\.com|meet\.jit\.si|([a-zA-Z0-9-]+\.)?zoom\.us)/[^\s]+$'),
 plan text not null default '' check(length(plan)<=4000),
 status text not null default 'planned' check(status in ('planned','completed','cancelled')),
 check(ends_at>starts_at and ends_at<=starts_at+interval '8 hours'),
 exclude using gist(teacher_id with =,tstzrange(starts_at,ends_at,'[)') with &&) where(status='planned'),
 exclude using gist(student_id with =,tstzrange(starts_at,ends_at,'[)') with &&) where(status='planned')
);
create table public.teacher_notes (
 teacher_id uuid not null references public.teachers(id) on delete cascade,
 student_id uuid not null references public.profiles(id) on delete cascade,
 content text not null default '' check(length(content)<=4000),
 primary key(teacher_id,student_id)
);
create index requests_student on public.requests(student_id);
create index lessons_student on public.lessons(student_id,starts_at);
create index lessons_teacher on public.lessons(teacher_id,starts_at);

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path='' as $$
declare r text; n text;
begin
 r:=new.raw_user_meta_data->>'role'; n:=trim(new.raw_user_meta_data->>'name');
 if r not in ('teacher','student') or r is null or n is null or length(n)<2 or length(n)>100 or coalesce(new.raw_user_meta_data->>'adult_confirmed','false')<>'true' or coalesce(new.raw_user_meta_data->>'terms_version','')<>'2026-09-01' then raise exception 'Invalid registration'; end if;
 insert into public.profiles(id,name,role,terms_version,adult_confirmed) values(new.id,n,r,'2026-09-01',true);
 if r='teacher' then insert into public.teachers(id,name) values(new.id,n); end if;
 return new;
end;$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.teachers enable row level security;
alter table public.requests enable row level security;
alter table public.lessons enable row level security;
alter table public.teacher_notes enable row level security;
revoke all on public.profiles,public.teachers,public.requests,public.lessons,public.teacher_notes from anon,authenticated;
grant select on public.teachers to anon,authenticated;
grant select(id,name,role) on public.profiles to authenticated;
grant select on public.requests,public.lessons,public.teacher_notes to authenticated;
grant update(name,headline,bio,subjects,levels,price,city,photo_url,published) on public.teachers to authenticated;
grant insert(teacher_id,student_id,message,subject,level) on public.requests to authenticated;
grant update(status) on public.requests to authenticated;
grant insert(teacher_id,student_id,title,starts_at,ends_at,meeting_url,plan),update(title,starts_at,ends_at,meeting_url,plan,status) on public.lessons to authenticated;
grant insert,update on public.teacher_notes to authenticated;
create policy teacher_read on public.teachers for select using(published or id=(select auth.uid()));
create policy teacher_edit on public.teachers for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));
-- Security-definer helper avoids recursive profile/request RLS joins.
create function public.my_role() returns text language sql stable security definer set search_path='' as $$ select role from public.profiles where id=auth.uid() $$;
create policy profile_read on public.profiles for select to authenticated using(id=(select auth.uid()) or exists(select 1 from public.requests r where (r.teacher_id=auth.uid() and r.student_id=profiles.id) or (r.student_id=auth.uid() and r.teacher_id=profiles.id)));
create policy request_read on public.requests for select to authenticated using(teacher_id=(select auth.uid()) or student_id=(select auth.uid()));
create policy request_insert on public.requests for insert to authenticated with check(student_id=(select auth.uid()) and public.my_role()='student' and status='pending' and exists(select 1 from public.teachers t where t.id=teacher_id and t.published and requests.level=any(t.levels) and requests.subject=any(t.subjects)));
create policy request_update on public.requests for update to authenticated using(teacher_id=(select auth.uid())) with check(teacher_id=(select auth.uid()));
create policy lesson_read on public.lessons for select to authenticated using(teacher_id=(select auth.uid()) or student_id=(select auth.uid()));
create policy lesson_insert on public.lessons for insert to authenticated with check(teacher_id=(select auth.uid()) and starts_at>now() and exists(select 1 from public.requests r where r.teacher_id=auth.uid() and r.student_id=lessons.student_id and r.status='accepted'));
create policy lesson_update on public.lessons for update to authenticated using(teacher_id=(select auth.uid())) with check(teacher_id=(select auth.uid()));
create policy notes_read on public.teacher_notes for select to authenticated using(teacher_id=(select auth.uid()));
create policy notes_insert on public.teacher_notes for insert to authenticated with check(teacher_id=(select auth.uid()) and exists(select 1 from public.requests r where r.teacher_id=auth.uid() and r.student_id=teacher_notes.student_id and r.status='accepted'));
create policy notes_update on public.teacher_notes for update to authenticated using(teacher_id=(select auth.uid())) with check(teacher_id=(select auth.uid()));
revoke all on function public.handle_new_user() from public,anon,authenticated;
revoke all on function public.my_role() from public,anon;
grant execute on function public.my_role() to authenticated;
-- Public teacher photos. Never store student documents or private files here.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('teacher-photos','teacher-photos',true,3145728,array['image/jpeg','image/png','image/webp']);
create policy photo_insert on storage.objects for insert to authenticated with check(bucket_id='teacher-photos' and (storage.foldername(name))[1]=auth.uid()::text and public.my_role()='teacher');
create policy photo_update on storage.objects for update to authenticated using(bucket_id='teacher-photos' and (storage.foldername(name))[1]=auth.uid()::text) with check(bucket_id='teacher-photos' and (storage.foldername(name))[1]=auth.uid()::text);
create policy photo_delete on storage.objects for delete to authenticated using(bucket_id='teacher-photos' and (storage.foldername(name))[1]=auth.uid()::text);
create policy photo_select on storage.objects for select using(bucket_id='teacher-photos');
commit;
