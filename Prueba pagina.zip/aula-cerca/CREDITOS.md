# Créditos de las fotografías de demostración

Las imágenes son fotografías de stock de personas adultas. Se utilizan solo en perfiles ficticios identificados como ejemplos. No representan docentes, identidades verificadas, testimonios ni recomendaciones de estas personas.

- `teacher-1.jpg`: Michael Dam, [Unsplash](https://unsplash.com/photos/closeup-photography-of-woman-smiling-mEZ3PoFGs_k).
- `teacher-2.jpg`: [imagen de Unsplash](https://images.unsplash.com/photo-1500648767791-00dcc994a43e).
- `teacher-3.jpg`: [imagen de Unsplash](https://images.unsplash.com/photo-1580489944761-15a19d654956).
- `teacher-4.jpg`: [imagen de Unsplash](https://images.unsplash.com/photo-1506794778202-cad84cf45f1d).

[Licencia de Unsplash](https://unsplash.com/license). Reemplazar estos ejemplos por fotografías autorizadas de cada docente real. Las fotografías de ejemplo se sirven localmente; no se consulta a Unsplash al navegar la aplicación.

Iconos: Lucide. Componentes accesibles: Shadcn/Radix. La web toma como referencia funcional el modelo de búsqueda de docentes de Tusclases, con diseño, marca y textos propios.
