import test from 'node:test';
import assert from 'node:assert/strict';
import {meetingUrl,lessonSchema,teacherSchema,makeMeetingLink} from '../lib/validation.ts';
import {dayKey,calendarDays,fromInputDate,toInputDate} from '../lib/calendar.ts';
test('solo permite enlaces HTTPS de proveedores de clase conocidos',()=>{
 for(const url of ['https://meet.google.com/abc-defg-hij','https://us02web.zoom.us/j/123','https://meet.jit.si/aula-test',''])assert.equal(meetingUrl.safeParse(url).success,true,url);
 for(const url of ['javascript:alert(1)','https://meet.google.com.evil.test/a','https://x@meet.google.com/a','http://meet.jit.si/a','https://evilzoom.us/a','https://meet.google.com:123/a'])assert.equal(meetingUrl.safeParse(url).success,false,url);
});
test('rechaza duraciones inválidas y fechas pasadas',()=>{
 const start=Date.now()+86400000;const x={student_id:'00000000-0000-4000-8000-000000000001',title:'Fracciones',starts_at:new Date(start).toISOString(),ends_at:new Date(start+3600000).toISOString(),meeting_url:'',plan:''};
 assert.equal(lessonSchema.safeParse(x).success,true);
 assert.equal(lessonSchema.safeParse({...x,ends_at:x.starts_at}).success,false);
 assert.equal(lessonSchema.safeParse({...x,ends_at:new Date(start+9*3600000).toISOString()}).success,false);
 assert.equal(lessonSchema.safeParse({...x,starts_at:'2020-01-01T10:00:00Z'}).success,false);
});
test('la agenda conserva hora de Argentina independientemente del navegador',()=>{
 assert.equal(fromInputDate('2026-09-12T16:30'),'2026-09-12T19:30:00.000Z');
 assert.equal(toInputDate('2026-09-12T19:30:00Z'),'2026-09-12T16:30');
 assert.equal(dayKey('2026-09-02T01:00:00Z'),'2026-09-01');
});
test('calendario de 42 días empieza un lunes e incluye el fin de año',()=>{
 const days=calendarDays(new Date('2026-12-15T12:00:00Z'));
 assert.equal(days.length,42);assert.equal(days[0].getUTCDay(),1);assert.equal(new Set(days.map(dayKey)).size,42);assert(days.some(d=>dayKey(d)==='2027-01-01'));
});
test('perfiles requieren niveles válidos y descripción suficiente',()=>{
 const t={name:'Docente Ejemplo',headline:'Aprendé matemática',bio:'Una descripción de clases que alcanza el mínimo requerido de cincuenta caracteres.',subjects:['Matemática'],levels:['Primario'],price:1000,city:'Rosario',published:true};
 assert.equal(teacherSchema.safeParse(t).success,true);assert.equal(teacherSchema.safeParse({...t,levels:['Universitario']}).success,false);assert.equal(teacherSchema.safeParse({...t,subjects:[]}).success,false);
});
test('los enlaces generados usan una sala distinta según el identificador',()=>{assert.notEqual(makeMeetingLink('a'),makeMeetingLink('b'));assert.equal(meetingUrl.safeParse(makeMeetingLink(crypto.randomUUID())).success,true);});
