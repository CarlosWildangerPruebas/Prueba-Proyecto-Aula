import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {btree_gist} from '@electric-sql/pglite/contrib/btree_gist';
const ids={teacher:'10000000-0000-4000-8000-000000000001',other:'10000000-0000-4000-8000-000000000002',student:'20000000-0000-4000-8000-000000000001',stranger:'20000000-0000-4000-8000-000000000002'};
test('SQL completo: roles, privacidad, solicitudes, agenda y fotos',async t=>{
 const db=new PGlite({extensions:{btree_gist}});
 try {
 await db.exec(`create schema auth;create schema storage;create schema extensions;create role anon;create role authenticated;
 create table auth.users(id uuid primary key,raw_user_meta_data jsonb);
 create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
 grant usage on schema auth,public,storage to anon,authenticated;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id uuid default gen_random_uuid() primary key,bucket_id text,name text);
 alter table storage.objects enable row level security;grant select,insert,update,delete on storage.objects to authenticated;
 create function storage.foldername(name text) returns text[] language sql immutable as $$select string_to_array(name,'/')$$;`);
 await db.exec(await readFile(new URL('../supabase/schema.sql',import.meta.url),'utf8'));
 for(const [name,id] of Object.entries(ids)){await db.query('insert into auth.users values($1,$2)',[id,{role:['teacher','other'].includes(name)?'teacher':'student',name:`Persona ${name}`,adult_confirmed:true,terms_version:'2026-09-01'}]);}
 async function actor(id,role='authenticated'){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec(`set role ${role}`);}
 async function fails(sql,args=[]){await assert.rejects(()=>db.query(sql,args));}
 await t.test('no permite autoconceder rol de docente ni alterar condiciones',async()=>{await actor(ids.student);await fails("update profiles set role='teacher' where id=$1",[ids.student]);await fails("update profiles set terms_version='x' where id=$1",[ids.student]);});
 await t.test('docentes publican únicamente su perfil; anónimos no ven borradores',async()=>{await actor(ids.teacher);await db.query("update teachers set headline='Apoyo de matemática',bio=$1,subjects=ARRAY['Matemática'],levels=ARRAY['Primario'],city='Rosario',published=true where id=$2",['Descripción de la enseñanza con más de cincuenta caracteres para publicar el perfil.',ids.teacher]);const changed=await db.query("update teachers set name='Ataque' where id=$1 returning id",[ids.other]);assert.equal(changed.rows.length,0);await actor('','anon');assert.equal((await db.query('select * from teachers')).rows.length,1);await fails('select * from profiles');await fails('select * from lessons');});
 let requestId;
 await t.test('alumno envía solicitud propia y no puede aceptarla ni impersonar a otro',async()=>{await actor(ids.student);await fails("insert into requests(teacher_id,student_id,message,subject,level) values($1,$2,'Necesito practicar matemática','Matemática','Primario')",[ids.teacher,ids.stranger]);const result=await db.query("insert into requests(teacher_id,student_id,message,subject,level) values($1,$2,'Necesito practicar matemática','Matemática','Primario') returning id",[ids.teacher,ids.student]);requestId=result.rows[0].id;assert.equal((await db.query("update requests set status='accepted' where id=$1 returning id",[requestId])).rows.length,0);assert.equal((await db.query('select id from profiles')).rows.length,2);});
 const start='2099-09-01T19:00:00Z',end='2099-09-01T20:00:00Z';let lessonId;
 await t.test('docente requiere solicitud aceptada y rechaza superposición',async()=>{await actor(ids.teacher);const sql="insert into lessons(teacher_id,student_id,title,starts_at,ends_at) values($1,$2,'Fracciones',$3,$4) returning id";await fails(sql,[ids.teacher,ids.student,start,end]);await db.query("update requests set status='accepted' where id=$1",[requestId]);lessonId=(await db.query(sql,[ids.teacher,ids.student,start,end])).rows[0].id;await fails(sql,[ids.teacher,ids.student,'2099-09-01T19:30:00Z','2099-09-01T20:30:00Z']);await db.query("insert into teacher_notes values($1,$2,'Nota privada')",[ids.teacher,ids.student]);});
 await t.test('alumno lee su clase pero no notas privadas ni otras cuentas',async()=>{await actor(ids.student);assert.equal((await db.query('select * from lessons')).rows.length,1);assert.equal((await db.query('select * from teacher_notes')).rows.length,0);assert.equal((await db.query("update lessons set title='Ataque' returning id")).rows.length,0);await actor(ids.stranger);assert.equal((await db.query('select * from lessons')).rows.length,0);assert.equal((await db.query('select * from requests')).rows.length,0);assert.equal((await db.query('select id,name,role from profiles')).rows.length,1);await fails('select accepted_at from profiles');await actor(ids.other);assert.equal((await db.query('select * from teacher_notes')).rows.length,0);});
 await t.test('cancelar libera el horario; no permite modificar participantes',async()=>{await actor(ids.teacher);await fails('update lessons set student_id=$1 where id=$2',[ids.stranger,lessonId]);await db.query("update lessons set status='cancelled' where id=$1",[lessonId]);await db.query("insert into lessons(teacher_id,student_id,title,starts_at,ends_at) values($1,$2,'Nueva clase',$3,$4)",[ids.teacher,ids.student,start,end]);});
 await t.test('alumno no sube fotos y docente solo usa su carpeta',async()=>{await actor(ids.student);await fails("insert into storage.objects(bucket_id,name) values('teacher-photos',$1)",[`${ids.student}/profile.jpg`]);await actor(ids.teacher);await fails("insert into storage.objects(bucket_id,name) values('teacher-photos',$1)",[`${ids.other}/profile.jpg`]);await db.query("insert into storage.objects(bucket_id,name) values('teacher-photos',$1)",[`${ids.teacher}/profile.jpg`]);});
 }finally{await db.close();}
});
